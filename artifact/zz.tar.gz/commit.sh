#!/bin/bash
git add --all
git commit -m "xochui DRY_RUN asdasd"
git push origin master

