#!/bin/sh

node /src/server.js
